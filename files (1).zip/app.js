const ADMIN_PASSWORD = 'crown2025';

let categories = [];
let products = [];
let qtys = {};
let deliveryCharge = 400;
let freeDeliveryAbove = 0;
let logoDataUrl = null;
let logoMode = 'name';
let heroBgDataUrl = null;
let storeName1 = 'Crown';
let storeName2 = 'CC';
let tagline = '✦ Crown City Centre ✦ Ladies Fashion ✦';
let currentCat = 'all';
let nextProductId = 1;
let nextCatId = 1;
let salesPersons = [];
let nextSpId = 1;
let activeSp = null;

/* ========== FIREBASE ========== */
function waitForFirebase() {
  return new Promise(resolve => {
    if (window._fbReady !== undefined) { resolve(window._fbReady); return; }
    const t = setTimeout(() => resolve(false), 3000);
    window.addEventListener('fbready', () => { clearTimeout(t); resolve(!window._fbInitFailed); }, { once: true });
  });
}

async function persistLoad() {
  document.getElementById('productGrid').innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--muted);">⏳ Loading...</div>';
  try {
    const fbOk = await waitForFirebase();
    if (!fbOk) { renderProducts(); applyBranding(); return; }
    const data = await window._fbGet('crowncc/config');
    const images = await window._fbGet('crowncc/images');
    if (data) {
      if (images) {
        data.products && data.products.forEach(p => {
          if (p.imgData === '__ref__' && images['p_' + p.id]) p.imgData = images['p_' + p.id];
        });
        if (data.logoDataUrl === '__ref__' && images['logo']) data.logoDataUrl = images['logo'];
        if (data.heroBgDataUrl === '__ref__' && images['herobg']) data.heroBgDataUrl = images['herobg'];
      }
      applyStoreData(data);
    }
    applyBranding(); renderCatTabs(); renderProducts(); detectSalesPerson();
  } catch(e) { console.warn(e); renderProducts(); applyBranding(); }
}

function applyStoreData(d) {
  if (!d) return;
  if (d.storeName1 !== undefined) storeName1 = d.storeName1;
  if (d.storeName2 !== undefined) storeName2 = d.storeName2;
  if (d.tagline !== undefined) tagline = d.tagline;
  if (d.categories !== undefined) categories = d.categories;
  if (d.products !== undefined) products = d.products;
  if (d.logoDataUrl !== undefined) logoDataUrl = d.logoDataUrl;
  if (d.logoMode !== undefined) logoMode = d.logoMode;
  if (d.deliveryCharge !== undefined) deliveryCharge = d.deliveryCharge;
  if (d.freeDeliveryAbove !== undefined) freeDeliveryAbove = d.freeDeliveryAbove;
  if (d.salesPersons !== undefined) salesPersons = d.salesPersons;
  if (d.nextProductId !== undefined) nextProductId = d.nextProductId;
  if (d.nextCatId !== undefined) nextCatId = d.nextCatId;
  if (d.nextSpId !== undefined) nextSpId = d.nextSpId;
  if (d.heroBgDataUrl !== undefined) heroBgDataUrl = d.heroBgDataUrl;
}

function applyBranding() {
  document.getElementById('heroName').innerHTML = `<span class="crown-text">${storeName1}</span><br><span class="cc-text">${storeName2}</span>`;
  // Apply hero bg image
  const header = document.querySelector('header');
  const overlay = document.getElementById('heroBgOverlay');
  if (heroBgDataUrl) {
    header.style.backgroundImage = `url(${heroBgDataUrl})`;
    if (overlay) overlay.style.display = 'block';
  } else {
    header.style.backgroundImage = '';
    if (overlay) overlay.style.display = 'none';
  }
  document.getElementById('navLogoText').innerHTML = `${storeName1} <span>${storeName2}</span>`;
  document.getElementById('heroTagline').textContent = tagline;
  document.getElementById('footBrand').innerHTML = `${storeName1} <span>${storeName2}</span>`;
  const logoImg = document.getElementById('navLogoImg');
  if (logoDataUrl && logoMode !== 'name') {
    logoImg.src = logoDataUrl; logoImg.style.display = 'block';
    if (logoMode === 'logo') document.getElementById('navLogoText').style.display = 'none';
  } else {
    logoImg.style.display = 'none';
    document.getElementById('navLogoText').style.display = 'block';
  }
}

/* ========== RENDER PRODUCTS ========== */
function renderProducts() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  if (products.length === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--muted);">👗 Products coming soon...</div>';
    return;
  }
  products.forEach(p => {
    const q = qtys[p.id] || 0;
    const oos = !p.inStock;
    const cat = categories.find(c => c.id === p.catId);
    const card = document.createElement('div');
    card.className = 'card' + (q > 0 ? ' in-cart' : '') + (oos ? ' out-of-stock' : '') + (currentCat !== 'all' && p.catId !== currentCat ? ' hidden-card' : '');
    card.id = 'card-' + p.id;

    // Image
    const imgContent = p.imgData
      ? `<img src="${p.imgData}" alt="${p.name}" loading="lazy">`
      : `<span>${p.emoji || '👗'}</span>`;

    // Item code badge
    const itemCodeBadge = p.itemCode ? `<div class="item-code-badge">${p.itemCode}</div>` : '';

    // Bottom tag
    const bottomTag = p.freeDelivery
      ? `<div class="free-delivery-tag">🚚 Free Delivery</div>`
      : (cat ? `<div class="cat-label-tag">${cat.name}</div>` : '');

    // Color swatches with visible stock numbers
    let colorSwatchHTML = '';
    if (p.colors && p.colors.length > 0) {
      const swatches = p.colors.map(c => {
        const isOut = (c.stock !== undefined && c.stock <= 0);
        const outClass = isOut ? ' out-swatch' : '';
        const wrapClass = isOut ? ' out-wrap' : '';
        const stockNum = (c.stock !== undefined) ? c.stock : -1;
        const badgeClass = isOut ? 'csb-out' : (stockNum >= 0 && stockNum <= 3 ? 'csb-low' : 'csb-ok');
        const badgeText = isOut ? 'Out' : (stockNum >= 0 ? stockNum : String.fromCharCode(10003));
        const safeName = c.name.replace(/'/g, "\'");
        const clickFn = isOut ? '' : ('selectColor(' + p.id + ', \'' + safeName + '\', \'' + c.hex + '\', ' + stockNum + ', this)');
        return '<div class="color-swatch-wrap' + wrapClass + '" onclick="' + clickFn + '" title="' + c.name + '">' +
          '<div class="color-swatch' + outClass + '" style="background:' + c.hex + '"></div>' +
          '<span class="color-stock-badge ' + badgeClass + '">' + badgeText + '</span>' +
          '</div>';
      }).join('');
      const stockInfo = '<div class="color-stock-label" id="color-label-' + p.id + '">🎨 Colour select කරන්න</div>';
      colorSwatchHTML = '<div class="color-stock-row">' + swatches + stockInfo + '</div>';
    }

    card.innerHTML = `
      <div class="card-img" onclick="openLightbox('${p.imgData || ''}','${p.name}','${p.itemCode || ''}')">
        ${imgContent}
        ${itemCodeBadge}
        ${p.badge ? `<span class="card-badge">${p.badge}</span>` : ''}
        <span class="stock-badge ${p.inStock ? 'available' : 'out'}">${p.inStock ? '✓ Available' : 'Out of Stock'}</span>
        ${bottomTag}
        <span class="card-img-zoom-hint">🔍 View</span>
      </div>
      ${colorSwatchHTML}
      <div class="card-body">
        <div class="card-name">${p.name}</div>
        <div class="card-desc" style="white-space:pre-line;">${p.desc || ''}</div>
        <div class="card-footer">
          <div class="price">Rs. ${p.price.toLocaleString()} <small>/piece</small></div>
          <div class="qty-ctrl">
            <button class="qty-btn" onclick="changeQty(${p.id},-1)" ${q === 0 || oos ? 'disabled' : ''}>−</button>
            <span class="qty-val" id="qty-${p.id}">${q}</span>
            <button class="qty-btn" onclick="changeQty(${p.id},1)" ${oos ? 'disabled' : ''}>+</button>
          </div>
        </div>
      </div>`;
    grid.appendChild(card);
  });
}

/* ========== COLOR SELECT ========== */
function selectColor(productId, colorName, hex, stock, wrapEl) {
  const label = document.getElementById('color-label-' + productId);
  const card = document.getElementById('card-' + productId);
  // Remove selected from all swatch wraps
  card.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('selected-swatch'));
  // Select inner swatch div
  const swatchDiv = wrapEl.querySelector('.color-swatch');
  if (swatchDiv) swatchDiv.classList.add('selected-swatch');
  if (label) {
    const stockTxt = stock < 0 ? '' : (stock === 0 ? ' — Out of Stock' : ' — ' + stock + ' remaining');
    label.innerHTML = '✓ <strong>' + colorName + '</strong>' + stockTxt;
    label.style.color = stock === 0 ? '#ef4444' : stock <= 3 && stock >= 0 ? '#d97706' : '#16a34a';
  }
}

/* ========== LIGHTBOX ========== */
function openLightbox(imgSrc, name, code) {
  if (!imgSrc) return;
  document.getElementById('lightboxImg').src = imgSrc;
  document.getElementById('lightboxName').textContent = name;
  document.getElementById('lightboxCode').textContent = code ? 'Item Code: ' + code : '';
  document.getElementById('lightboxOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  document.getElementById('lightboxOverlay').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

/* ========== CART & QTY ========== */
function changeQty(id, delta) {
  const p = products.find(x => x.id === id);
  if (!p || !p.inStock) return;
  qtys[id] = Math.max(0, (qtys[id] || 0) + delta);
  const qEl = document.getElementById('qty-' + id);
  if (qEl) qEl.textContent = qtys[id];
  const card = document.getElementById('card-' + id);
  if (card) {
    card.classList.toggle('in-cart', qtys[id] > 0);
    card.querySelectorAll('.qty-btn')[0].disabled = qtys[id] === 0;
  }
  updateCart();
}

function calcDelivery(subtotal) {
  let allFree = true, anySelected = false;
  products.forEach(p => {
    if ((qtys[p.id] || 0) > 0) { anySelected = true; if (!p.freeDelivery) allFree = false; }
  });
  if (!anySelected) return 0;
  if (allFree) return 0;
  if (freeDeliveryAbove > 0 && subtotal >= freeDeliveryAbove) return 0;
  return deliveryCharge;
}

function updateCart() {
  let subtotal = 0, count = 0;
  products.forEach(p => { const q = qtys[p.id] || 0; subtotal += q * p.price; count += q; });
  const delivery = calcDelivery(subtotal);
  const total = subtotal + delivery;
  const bar = document.getElementById('cartBar');
  if (count > 0) {
    bar.classList.add('visible');
    document.getElementById('cartCount').textContent = count;
    document.getElementById('cartSubtotal').textContent = subtotal.toLocaleString();
  } else {
    bar.classList.remove('visible');
  }
  const summaryItems = document.getElementById('summaryItems');
  const noMsg = document.getElementById('noItemsMsg');
  const footer = document.getElementById('summaryFooter');
  summaryItems.innerHTML = '';
  if (count > 0) {
    noMsg.style.display = 'none';
    products.forEach(p => {
      const q = qtys[p.id] || 0;
      if (q > 0) {
        const row = document.createElement('div');
        row.className = 'summary-row';
        const codeSpan = p.itemCode ? `<span class="summary-row-code">${p.itemCode}</span> ` : '';
        row.innerHTML = `<span>${codeSpan}${p.name} × ${q}</span><span>Rs. ${(q * p.price).toLocaleString()}</span>`;
        summaryItems.appendChild(row);
      }
    });
    document.getElementById('formTotal').textContent = total.toLocaleString();
    document.getElementById('deliveryLabel').textContent = delivery === 0 ? '🚚 Delivery (Free)' : 'Delivery';
    document.getElementById('deliveryValue').textContent = delivery === 0 ? 'FREE' : 'Rs. ' + delivery.toLocaleString();
    footer.style.display = 'block';
  } else {
    noMsg.style.display = 'block';
    footer.style.display = 'none';
  }
}

/* ========== ORDER MODAL ========== */
function openOrderModal() { renderOrderModal(); document.getElementById('orderSummaryModal').classList.add('open'); }
function closeOrderModal() { document.getElementById('orderSummaryModal').classList.remove('open'); }

function renderOrderModal() {
  const list = document.getElementById('omItemsList');
  const footer = document.getElementById('omFooter');
  list.innerHTML = '';
  const selected = products.filter(p => (qtys[p.id] || 0) > 0);
  if (selected.length === 0) { list.innerHTML = '<div class="om-empty">🛒 No items selected</div>'; footer.style.display = 'none'; return; }
  let subtotal = 0;
  selected.forEach(p => {
    const q = qtys[p.id] || 0;
    subtotal += q * p.price;
    const div = document.createElement('div');
    div.className = 'om-item';
    div.id = 'om-row-' + p.id;
    const codeHTML = p.itemCode ? `<div class="om-item-code">📌 ${p.itemCode}</div>` : '';
    div.innerHTML = `
      <div class="om-item-info"><div class="om-item-name">${p.name}</div>${codeHTML}</div>
      <div class="om-qty-ctrl">
        <button class="om-qty-btn" onclick="omChangeQty(${p.id},-1)">−</button>
        <span class="om-qty-val" id="om-qty-${p.id}">${q}</span>
        <button class="om-qty-btn" onclick="omChangeQty(${p.id},1)">+</button>
      </div>
      <div class="om-item-price" id="om-price-${p.id}">Rs. ${(q * p.price).toLocaleString()}</div>
      <button class="om-remove-btn" onclick="omRemoveItem(${p.id})">🗑</button>`;
    list.appendChild(div);
  });
  const delivery = calcDelivery(subtotal);
  const total = subtotal + delivery;
  document.getElementById('omSubtotal').textContent = 'Rs. ' + subtotal.toLocaleString();
  document.getElementById('omDelivery').textContent = delivery === 0 ? 'FREE' : 'Rs. ' + delivery.toLocaleString();
  document.getElementById('omDeliveryLabel').textContent = delivery === 0 ? '🚚 Delivery (Free)' : 'Delivery';
  document.getElementById('omTotal').textContent = 'Rs. ' + total.toLocaleString();
  footer.style.display = 'block';
}

function omChangeQty(id, delta) {
  const p = products.find(x => x.id === id);
  if (!p || !p.inStock) return;
  const newQty = Math.max(0, (qtys[id] || 0) + delta);
  qtys[id] = newQty;
  if (newQty === 0) {
    const row = document.getElementById('om-row-' + id);
    if (row) row.remove();
  } else {
    const qEl = document.getElementById('om-qty-' + id);
    const pEl = document.getElementById('om-price-' + id);
    if (qEl) qEl.textContent = newQty;
    if (pEl) pEl.textContent = 'Rs. ' + (newQty * p.price).toLocaleString();
  }
  const cardQEl = document.getElementById('qty-' + id);
  if (cardQEl) cardQEl.textContent = newQty;
  const card = document.getElementById('card-' + id);
  if (card) { card.classList.toggle('in-cart', newQty > 0); card.querySelectorAll('.qty-btn')[0].disabled = newQty === 0; }
  updateCart();
  renderOrderModal();
}
function omRemoveItem(id) {
  qtys[id] = 0;
  const cardQEl = document.getElementById('qty-' + id);
  if (cardQEl) cardQEl.textContent = 0;
  const card = document.getElementById('card-' + id);
  if (card) { card.classList.remove('in-cart'); card.querySelectorAll('.qty-btn')[0].disabled = true; }
  updateCart(); renderOrderModal();
}
function confirmOrder() { closeOrderModal(); document.getElementById('order').scrollIntoView({ behavior: 'smooth' }); }

/* ========== ORDER FORM SUBMIT ========== */
function validatePhone(val) { return /^[0-9]{10}$/.test(val.replace(/\s/g, '')); }

document.getElementById('orderForm').addEventListener('submit', function(e) {
  e.preventDefault();
  let valid = true;
  const p1 = document.getElementById('custPhone1').value.replace(/\s/g, '');
  const itemCode = document.getElementById('custItemCode').value.trim();

  document.getElementById('errPhone1').style.display = 'none';
  document.getElementById('errItemCode').style.display = 'none';

  if (!validatePhone(p1)) {
    document.getElementById('errPhone1').style.display = 'block'; valid = false;
  }
  if (!itemCode) {
    document.getElementById('errItemCode').style.display = 'block'; valid = false;
  }
  if (!valid) return;

  const name = document.getElementById('custName').value;
  const address = document.getElementById('custAddress').value;
  const city = document.getElementById('custCity').value;
  const phone2 = document.getElementById('custPhone2').value;
  const note = document.getElementById('custNote').value;

  let itemsList = '', subtotal = 0;
  const hasSelected = products.some(p => (qtys[p.id] || 0) > 0);

  if (hasSelected) {
    products.forEach(p => {
      const q = qtys[p.id] || 0;
      if (q > 0) {
        const code = p.itemCode ? `[${p.itemCode}] ` : '';
        itemsList += `• ${code}${p.name} × ${q}\n`;
        subtotal += q * p.price;
      }
    });
  } else {
    itemsList = `• Item Code: ${itemCode}\n`;
  }

  const delivery = calcDelivery(subtotal);
  const total = subtotal + delivery;

  let msg = `👑 *New Order — Crown CC* 👑\n\n`;
  msg += `👤 *Name:* ${name}\n`;
  msg += `📍 *Address:* ${address}, ${city}\n`;
  msg += `📞 *Phone 1:* ${p1}\n`;
  if (phone2) msg += `📞 *Phone 2:* ${phone2}\n`;
  msg += `\n🛍️ *Items:*\n${itemsList}`;
  msg += `📦 *Item Code(s):* ${itemCode}\n`;
  if (subtotal > 0) {
    msg += `\n💰 *Subtotal:* Rs. ${subtotal.toLocaleString()}\n`;
    msg += `🚚 *Delivery:* ${delivery === 0 ? 'FREE' : 'Rs. ' + delivery.toLocaleString()}\n`;
    msg += `✅ *Total:* Rs. ${total.toLocaleString()}\n`;
  }
  if (note) msg += `\n📝 *Note:* ${note}`;

  const waNum = getActiveWaNumber();
  window.open(`https://wa.me/${waNum}?text=${encodeURIComponent(msg)}`, '_blank');
});

/* ========== SALES PERSONS ========== */
function detectSalesPerson() {
  const params = new URLSearchParams(window.location.search);
  const spId = params.get('sp');
  if (!spId) return;
  const sp = salesPersons.find(s => s.id === spId);
  if (!sp) return;
  activeSp = sp;
  document.getElementById('spBannerName').textContent = sp.name;
  document.getElementById('spBanner').classList.add('show');
  document.querySelector('header').style.marginTop = '30px';
}
function getActiveWaNumber() {
  if (activeSp) { let num = activeSp.phone.replace(/\s/g, ''); if (num.startsWith('0')) num = '94' + num.slice(1); return num; }
  return '94728626128';
}
function getSiteUrl() { return window.location.origin + window.location.pathname; }

/* ========== CATEGORIES ========== */
function renderCatTabs() {
  const navC = document.getElementById('navCenter');
  navC.innerHTML = `<a href="#products" class="nav-tab ${currentCat === 'all' ? 'active' : ''}" onclick="showCategory('all',this)">All</a>`;
  categories.forEach(c => {
    const a = document.createElement('a');
    a.href = '#products'; a.className = 'nav-tab' + (currentCat === c.id ? ' active' : '');
    a.textContent = c.name; a.onclick = function() { showCategory(c.id, this); };
    navC.appendChild(a);
  });
  const sec = document.getElementById('catTabsSection');
  sec.innerHTML = `<button class="cat-tab ${currentCat === 'all' ? 'active' : ''}" onclick="showCategory('all',this)">All</button>`;
  categories.forEach(c => {
    const btn = document.createElement('button');
    btn.className = 'cat-tab' + (currentCat === c.id ? ' active' : '');
    btn.textContent = c.name; btn.onclick = function() { showCategory(c.id, this); };
    sec.appendChild(btn);
  });
}
function showCategory(catId, el) {
  currentCat = catId;
  document.querySelectorAll('.nav-tab, .cat-tab').forEach(t => t.classList.remove('active'));
  if (el) el.classList.add('active');
  filterProducts();
}
function filterProducts() {
  products.forEach(p => {
    const card = document.getElementById('card-' + p.id);
    if (!card) return;
    if (currentCat === 'all' || p.catId === currentCat) card.classList.remove('hidden-card');
    else card.classList.add('hidden-card');
  });
}

/* ========== ADMIN ========== */
function askAdminPassword() { document.getElementById('adminPwInput').value = ''; document.getElementById('pwError').style.display = 'none'; document.getElementById('pwOverlay').classList.add('open'); }
function checkAdminPw() {
  if (document.getElementById('adminPwInput').value === ADMIN_PASSWORD) {
    document.getElementById('pwOverlay').classList.remove('open');
    document.getElementById('adminOverlay').classList.add('open');
    buildProductAdmin();
  } else {
    document.getElementById('pwError').style.display = 'block';
  }
}
function adminLogout() { document.getElementById('adminOverlay').classList.remove('open'); }

function previewHeroBg(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    heroBgDataUrl = e.target.result;
    const box = document.getElementById('heroBgPreviewBox');
    box.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;" alt="hero bg">`;
    // Live preview on header
    const header = document.querySelector('header');
    const overlay = document.getElementById('heroBgOverlay');
    header.style.backgroundImage = `url(${e.target.result})`;
    if (overlay) overlay.style.display = 'block';
  };
  reader.readAsDataURL(file);
}

function previewLogo(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    logoDataUrl = e.target.result;
    const box = document.getElementById('logoPreviewBox');
    box.innerHTML = `<img src="${logoDataUrl}" alt="logo">`;
  };
  reader.readAsDataURL(file);
}

function buildProductAdmin() {
  // Populate current values
  document.getElementById('aStoreName1').value = storeName1;
  document.getElementById('aStoreName2').value = storeName2;
  document.getElementById('aTagline').value = tagline;
  document.getElementById('aDeliveryCharge').value = deliveryCharge;
  document.getElementById('aFreeDeliveryAbove').value = freeDeliveryAbove;
  document.getElementById('aLogoMode').value = logoMode;
  // Show existing hero bg preview
  if (heroBgDataUrl) {
    const hbox = document.getElementById('heroBgPreviewBox');
    if (hbox) hbox.innerHTML = `<img src="${heroBgDataUrl}" style="width:100%;height:100%;object-fit:cover;" alt="hero bg">`;
  }
  if (logoDataUrl) {
    document.getElementById('logoPreviewBox').innerHTML = `<img src="${logoDataUrl}" alt="logo">`;
  }

  // Categories
  const catList = document.getElementById('catAdminList');
  catList.innerHTML = '';
  categories.forEach(c => {
    const div = document.createElement('div');
    div.className = 'admin-row';
    div.id = 'cat-row-' + c.id;
    div.innerHTML = `<div class="admin-field"><label>Category Name</label><input type="text" id="cat-name-${c.id}" value="${c.name}"></div><button class="del-product-btn" onclick="removeCategory('${c.id}')">🗑</button>`;
    catList.appendChild(div);
  });

  // Sales persons
  const spList = document.getElementById('spAdminList');
  spList.innerHTML = '';
  salesPersons.forEach(sp => {
    const div = document.createElement('div');
    div.className = 'sp-card';
    div.id = 'sp-row-' + sp.id;
    div.innerHTML = `
      <div class="admin-row">
        <div class="admin-field"><label>Name</label><input type="text" id="sp-name-${sp.id}" value="${sp.name}"></div>
        <div class="admin-field"><label>Phone</label><input type="text" id="sp-phone-${sp.id}" value="${sp.phone}"></div>
        <button class="del-product-btn" onclick="removeSalesPerson('${sp.id}')">🗑</button>
      </div>
      <div class="sp-link-box" onclick="copySpLink('${sp.id}')">🔗 ${getSiteUrl()}?sp=${sp.id} <span class="copy-hint">Copy</span></div>`;
    spList.appendChild(div);
  });

  // Products
  const pList = document.getElementById('productAdminList');
  pList.innerHTML = '';
  products.forEach(p => renderProductAdminCard(p));
}

function renderProductAdminCard(p) {
  const pList = document.getElementById('productAdminList');
  const div = document.createElement('div');
  div.className = 'product-admin-card';
  div.id = 'padmin-' + p.id;
  const catOptions = categories.map(c => `<option value="${c.id}" ${p.catId === c.id ? 'selected' : ''}>${c.name}</option>`).join('');

  // Colors HTML
  const colorsJSON = JSON.stringify(p.colors || []).replace(/"/g, '&quot;');
  let colorsDisplay = '';
  if (p.colors && p.colors.length > 0) {
    colorsDisplay = p.colors.map(c => `
      <div class="color-admin-item" id="cadmin-${p.id}-${c.name.replace(/\s/g,'_')}">
        <div class="color-admin-swatch-preview" style="background:${c.hex}"></div>
        <span>${c.name} (stock: ${c.stock ?? '∞'})</span>
        <button onclick="removeProductColor(${p.id},'${c.name}')">✕</button>
      </div>`).join('');
  }

  div.innerHTML = `
    <div class="product-admin-card-title" style="display:flex;align-items:center;justify-content:space-between;">
      <span>Product #${p.id} — ${p.name}</span>
      <button class="del-product-btn" onclick="removeProduct(${p.id})">🗑 Remove</button>
    </div>
    <div class="admin-row">
      <div class="admin-field"><label>Item Code *</label><input type="text" id="p-itemcode-${p.id}" value="${p.itemCode || ''}"></div>
      <div class="admin-field"><label>Product Name *</label><input type="text" id="p-name-${p.id}" value="${p.name}"></div>
    </div>
    <div class="admin-row">
      <div class="admin-field"><label>Price (Rs.)</label><input type="number" id="p-price-${p.id}" value="${p.price}" min="0"></div>
      <div class="admin-field"><label>Category</label><select id="p-cat-${p.id}"><option value="">Uncategorised</option>${catOptions}</select></div>
    </div>
    <div class="admin-row">
      <div class="admin-field"><label>Description</label><textarea id="p-desc-${p.id}" style="min-height:60px;">${p.desc || ''}</textarea></div>
    </div>
    <div class="admin-row">
      <div class="admin-field"><label>Badge (e.g. NEW, SALE)</label><input type="text" id="p-badge-${p.id}" value="${p.badge || ''}"></div>
      <div class="admin-field"><label>Emoji (if no image)</label><input type="text" id="p-emoji-${p.id}" value="${p.emoji || '👗'}"></div>
    </div>
    <div class="admin-row" style="align-items:flex-end;gap:1rem;">
      <div class="admin-field"><label>Product Image</label><input type="file" id="p-img-${p.id}" accept="image/*" onchange="previewProductImg(${p.id},this)"></div>
      <div class="img-preview-admin" id="p-img-preview-${p.id}">${p.imgData ? `<img src="${p.imgData}" alt="">` : (p.emoji || '👗')}</div>
    </div>
    <div class="admin-row">
      <div class="admin-field" style="display:flex;align-items:center;gap:.8rem;flex-wrap:wrap;">
        <label><input type="checkbox" id="p-instock-${p.id}" ${p.inStock ? 'checked' : ''}> In Stock</label>
        <label><input type="checkbox" id="p-freedel-${p.id}" ${p.freeDelivery ? 'checked' : ''}> Free Delivery</label>
      </div>
    </div>

    <div style="margin-top:.8rem;">
      <div style="font-size:.72rem;color:rgba(255,255,255,.5);letter-spacing:.08em;text-transform:uppercase;margin-bottom:.4rem;">Colour Stock</div>
      <div class="color-admin-list" id="color-admin-list-${p.id}">${colorsDisplay}</div>
      <div class="add-color-row">
        <input type="color" id="color-hex-${p.id}" value="#ff69b4">
        <input type="text" id="color-name-${p.id}" placeholder="Colour name (e.g. Pink)">
        <input type="number" id="color-stock-${p.id}" placeholder="Stock qty" min="0" style="width:90px;padding:.5rem .7rem;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:.82rem;border-radius:3px;">
        <button onclick="addProductColor(${p.id})">+ Add</button>
      </div>
    </div>`;
  pList.appendChild(div);
}

function previewProductImg(id, input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById('p-img-preview-' + id);
    if (preview) preview.innerHTML = `<img src="${e.target.result}" alt="">`;
    const p = products.find(x => x.id === id);
    if (p) p._newImgData = e.target.result;
  };
  reader.readAsDataURL(file);
}

function addProductColor(productId) {
  const hex = document.getElementById('color-hex-' + productId).value;
  const name = document.getElementById('color-name-' + productId).value.trim();
  const stock = parseInt(document.getElementById('color-stock-' + productId).value) || 0;
  if (!name) { alert('Colour name enter කරන්න'); return; }
  const p = products.find(x => x.id === productId);
  if (!p) return;
  if (!p.colors) p.colors = [];
  if (p.colors.find(c => c.name === name)) { alert('Colour already exists'); return; }
  p.colors.push({ hex, name, stock });

  const list = document.getElementById('color-admin-list-' + productId);
  const item = document.createElement('div');
  item.className = 'color-admin-item';
  item.id = 'cadmin-' + productId + '-' + name.replace(/\s/g, '_');
  item.innerHTML = `<div class="color-admin-swatch-preview" style="background:${hex}"></div><span>${name} (stock: ${stock})</span><button onclick="removeProductColor(${productId},'${name}')">✕</button>`;
  list.appendChild(item);
  document.getElementById('color-name-' + productId).value = '';
  document.getElementById('color-stock-' + productId).value = '';
}

function removeProductColor(productId, colorName) {
  const p = products.find(x => x.id === productId);
  if (!p) return;
  p.colors = (p.colors || []).filter(c => c.name !== colorName);
  const item = document.getElementById('cadmin-' + productId + '-' + colorName.replace(/\s/g, '_'));
  if (item) item.remove();
}

function addCategory() {
  const id = 'cat' + nextCatId++;
  categories.push({ id, name: 'New Category' });
  const catList = document.getElementById('catAdminList');
  const div = document.createElement('div');
  div.className = 'admin-row';
  div.id = 'cat-row-' + id;
  div.innerHTML = `<div class="admin-field"><label>Category Name</label><input type="text" id="cat-name-${id}" value="New Category"></div><button class="del-product-btn" onclick="removeCategory('${id}')">🗑</button>`;
  catList.appendChild(div);
}
function removeCategory(id) {
  categories = categories.filter(c => c.id !== id);
  const row = document.getElementById('cat-row-' + id);
  if (row) row.remove();
}

function addProduct() {
  const id = nextProductId++;
  products.push({ id, name: 'New Product', price: 0, inStock: true, freeDelivery: false, catId: '', desc: '', badge: '', emoji: '👗', imgData: null, itemCode: '', colors: [] });
  renderProductAdminCard(products[products.length - 1]);
}
function removeProduct(id) {
  products = products.filter(p => p.id !== id);
  const el = document.getElementById('padmin-' + id);
  if (el) el.remove();
}

function addSalesPerson() {
  const id = 'sp' + nextSpId++;
  salesPersons.push({ id, name: 'New Person', phone: '07XXXXXXXX' });
  buildProductAdmin();
}
function removeSalesPerson(id) {
  salesPersons = salesPersons.filter(s => s.id !== id);
  buildProductAdmin();
}

function copySpLink(spId) {
  const url = getSiteUrl() + '?sp=' + spId;
  navigator.clipboard.writeText(url).then(() => alert('Link copied! ✓'));
}

function saveAdmin() {
  // Read branding
  // Hero bg clear
  if (document.getElementById('aHeroBgClear') && document.getElementById('aHeroBgClear').checked) {
    heroBgDataUrl = null;
    const header = document.querySelector('header');
    header.style.backgroundImage = '';
    const overlay = document.getElementById('heroBgOverlay');
    if (overlay) overlay.style.display = 'none';
  }
  storeName1 = document.getElementById('aStoreName1').value;
  storeName2 = document.getElementById('aStoreName2').value;
  tagline = document.getElementById('aTagline').value;
  deliveryCharge = parseInt(document.getElementById('aDeliveryCharge').value) || 400;
  freeDeliveryAbove = parseInt(document.getElementById('aFreeDeliveryAbove').value) || 0;
  logoMode = document.getElementById('aLogoMode').value;

  // Read categories
  categories.forEach(c => {
    const el = document.getElementById('cat-name-' + c.id);
    if (el) c.name = el.value;
  });

  // Read sales persons
  salesPersons.forEach(sp => {
    const nameEl = document.getElementById('sp-name-' + sp.id);
    const phoneEl = document.getElementById('sp-phone-' + sp.id);
    if (nameEl) sp.name = nameEl.value;
    if (phoneEl) sp.phone = phoneEl.value;
  });

  // Read products
  products.forEach(p => {
    const nameEl = document.getElementById('p-name-' + p.id);
    if (nameEl) p.name = nameEl.value;
    const itemcodeEl = document.getElementById('p-itemcode-' + p.id);
    if (itemcodeEl) p.itemCode = itemcodeEl.value.trim();
    const priceEl = document.getElementById('p-price-' + p.id);
    if (priceEl) p.price = parseInt(priceEl.value) || 0;
    const catEl = document.getElementById('p-cat-' + p.id);
    if (catEl) p.catId = catEl.value;
    const descEl = document.getElementById('p-desc-' + p.id);
    if (descEl) p.desc = descEl.value;
    const badgeEl = document.getElementById('p-badge-' + p.id);
    if (badgeEl) p.badge = badgeEl.value;
    const emojiEl = document.getElementById('p-emoji-' + p.id);
    if (emojiEl) p.emoji = emojiEl.value;
    const instockEl = document.getElementById('p-instock-' + p.id);
    if (instockEl) p.inStock = instockEl.checked;
    const freedelEl = document.getElementById('p-freedel-' + p.id);
    if (freedelEl) p.freeDelivery = freedelEl.checked;
    if (p._newImgData) { p.imgData = p._newImgData; delete p._newImgData; }
  });

  persistSave();
  applyBranding();
  renderCatTabs();
  renderProducts();
  document.getElementById('adminOverlay').classList.remove('open');
  alert('✅ Changes saved!');
}

async function persistSave() {
  const fbOk = await waitForFirebase();
  if (!fbOk) return;

  const images = {};
  if (logoDataUrl && logoDataUrl.length > 100) {
    images['logo'] = logoDataUrl;
  }
  if (heroBgDataUrl && heroBgDataUrl.length > 100) {
    images['herobg'] = heroBgDataUrl;
  }

  const productsData = products.map(p => {
    const cp = { ...p };
    if (cp.imgData && cp.imgData.length > 500) {
      images['p_' + cp.id] = cp.imgData;
      cp.imgData = '__ref__';
    }
    return cp;
  });

  const configData = {
    storeName1, storeName2, tagline, deliveryCharge, freeDeliveryAbove, logoMode,
    logoDataUrl: (logoDataUrl && logoDataUrl.length > 100) ? '__ref__' : logoDataUrl,
    heroBgDataUrl: (heroBgDataUrl && heroBgDataUrl.length > 100) ? '__ref__' : heroBgDataUrl,
    categories, products: productsData, salesPersons, nextProductId, nextCatId, nextSpId
  };

  try {
    await window._fbSet('crowncc/config', configData);
    if (Object.keys(images).length > 0) await window._fbSet('crowncc/images', images);
  } catch(e) { console.error('Save error:', e); }
}

// Show admin button on triple-click on nav logo text (same as original)
let clickCount = 0;
document.getElementById('navLogoText').addEventListener('click', () => {
  clickCount++;
  if (clickCount >= 3) { clickCount = 0; document.getElementById('adminBtn').style.display = 'block'; }
  setTimeout(() => { clickCount = 0; }, 2000);
});

persistLoad();