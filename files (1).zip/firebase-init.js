// Firebase Initialization — Crown CC
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getDatabase, ref, set, get } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBGoeRwb6VlEknQKaLSOSY2tyBUeLJzEI4",
  authDomain: "c-pearl-white.firebaseapp.com",
  databaseURL: "https://c-pearl-white-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "c-pearl-white",
  storageBucket: "c-pearl-white.firebasestorage.app",
  messagingSenderId: "647160306453",
  appId: "1:647160306453:web:646b71814ff5534560671c"
};

try {
  const app = initializeApp(firebaseConfig);
  const db = getDatabase(app);
  window._fbSet = (path, data) => set(ref(db, path), data);
  window._fbGet = (path) => get(ref(db, path)).then(snap => snap.exists() ? snap.val() : null);
  window._fbReady = true;
  setTimeout(() => window.dispatchEvent(new Event('fbready')), 0);
} catch(err) {
  console.error('Firebase init error:', err);
  window._fbReady = false;
  window._fbInitFailed = true;
  setTimeout(() => window.dispatchEvent(new Event('fbready')), 0);
}